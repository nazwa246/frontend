FRONTEND: index.html + style.css
